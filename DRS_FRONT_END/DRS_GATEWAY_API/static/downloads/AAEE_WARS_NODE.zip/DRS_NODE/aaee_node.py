from functions.monitorMode import *


if __name__== "__main__":
    startMonitorMode()