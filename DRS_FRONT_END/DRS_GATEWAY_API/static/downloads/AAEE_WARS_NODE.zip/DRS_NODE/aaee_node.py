from functions.monitorMode import *
import time


if __name__== "__main__":
	while True:
		startMonitorMode()
		time.sleep(1)
