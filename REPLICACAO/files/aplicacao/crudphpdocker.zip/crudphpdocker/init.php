<?php
require 'database/config.php';
require 'functions/functions.php';
